const pogger = require("pogger");
const colors = require("colors");
const { guildId, clientId, botActivity } = require("../config.json")

module.exports = async (client) => {
      pogger.success('[KLIENTAS]'.bgCyan,`${client.user.tag} paruoštas!`.green);
   client.user.setPresence({ activities: [{ name: botActivity, type: 'WATCHING' }], status: 'idle' });

if(guildId === "" || null){

  pogger.error(`[KLAIDA]`.bgRed, `Reikia Guild ID, kad būtų galima naudoti Slash komandas!`.underline.red);
  pogger.error(`[KLAIDA]`.bgRed, `Trūksta reikšmės: ./config.json => "guildId": ""`.red);
  pogger.error(`[KLAIDA]`.bgRed, `Repl.it buvo sustabdytas.`.red), process.exit();

  } else {

     if(clientId === "" || null){

        pogger.error(`[KLAIDA]`.bgRed, `Reikia Client ID, kad būtų galima naudoti Slash komandas!`.underline.red);
        pogger.error(`[KLAIDA]`.bgRed, `Trūksta reikšmės: ./config.json => "clientId": ""`.red);
        pogger.error(`[KLAIDA]`.bgRed, `Repl.it buvo sustabdytas.`.red), process.exit();

  }
}
};
pogger.debug("[ĮVYKIAI]".bgYellow, "Įkelta nauja įvykio komanda: ready.js".underline.bold.cyan)
