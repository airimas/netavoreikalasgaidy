const pogger = require("pogger");
const colors = require("colors");
const { MessageEmbed } = require("discord.js");
const { clientName, developerTag } = require("../config.json");

module.exports = async (client, message) => {
  if (message.channel.type === "dm") return;
  if (message.author.bot) return;
  if (!message.guild) return;
  if (!message.member)
    message.member = await message.guild.fetchMember(message);

  if (message.content.match(new RegExp(`^<@!?${client.user.id}>`))) {

    const embed = new MessageEmbed()
      .setTitle(`${clientName} - Pradėkime:`)
      .addFields(
        { name: "Boto ID:", value: `\`${client.user.id}\``, inline: true},
        { name: "Prefiksas:", value: `\`/\` (Slash Komandos)`, inline: true},
        { name: "Ikūrėjas:", value: `${developerTag}`, inline: true},
      )
      .setFooter(`Prašė: ${message.author.tag}`)

    return message.reply({ embeds: [embed] })
  }  
};
pogger.debug("[ĮVYKIAI]".bgYellow, "Įkelta nauja įvykio komanda: messageCreate.js".underline.bold.cyan)
