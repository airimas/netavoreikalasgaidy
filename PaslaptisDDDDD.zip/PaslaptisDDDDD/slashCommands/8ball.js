const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Užduok klausimą ir gauk atsakymą iš 8-ball! 🏀')
    .addStringOption(option =>
      option.setName('klausimas')
        .setDescription('Įveskite klausimą, į kurį norite atsakyti')
        .setRequired(true)
    ),

  async execute(client, interaction) {
    // Klausimo gavimas
    const question = interaction.options.getString('klausimas');

    // 8-ball atsakymai
    const answers = [
      'Taip.',
      'Ne.',
      'Galbūt.',
      'Tikrai ne.',
      'Nėra galimybės.',
      'Aš nesu tikras.',
      'Klauskite vėl vėliau.',
      'Atsakymas rūpi jums pačiam.',
      'Žinoma, kad taip!',
      'Tai neatrodo gerai.',
      'Aš neprivalau atsakyti.',
      'Tai neatrodo kaip geras klausimas.'
    ];

    // Atsitiktinis atsakymas
    const randomAnswer = answers[Math.floor(Math.random() * answers.length)];

    // Sukuriame embed su klausimu ir atsakymu
    const embed = new MessageEmbed()
      .setTitle('8-ball atsakymas')
      .setDescription(`**Klausimas**: ${question}\n**Atsakymas**: ${randomAnswer}`)
      .setColor('#3498db')
      .setFooter('Komanda sukurta @krccdm')
      .setTimestamp();

    // Atsakome su embed
    await interaction.reply({ embeds: [embed] });
  },
};
