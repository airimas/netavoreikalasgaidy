const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pasitvirtinti')
    .setDescription('Patvirtinkite save serveryje!'),
  async execute(client, interaction) {

    const { verifiedRoleId } = require("../config.json")
    const { successEmoji, errorEmoji } = require("../emojis.json")
    const verifiedRole = interaction.guild.roles.cache.find(role => role.id === verifiedRoleId);

    if (!verifiedRole)
    return console.log("[WARN] Patvirtinto vartotojo rolė neegzistuoja!");

    if (interaction.member.roles.cache.has(verifiedRole.id)) { 
      interaction.reply({ content: `\`⛔\` **Leidimai Atmesti:**\n\nJūs jau esate patvirtintas!`, ephemeral: true })
    } else {

      try {

        interaction.reply({ content: `${successEmoji} **Jūs buvote sėkmingai patvirtintas!**`, ephemeral: true })

        const role = interaction.guild.roles.cache.get(verifiedRoleId)

        await interaction.member.roles.add(role)

      } catch (err){

        console.log(err)
        interaction.channel.send({ content: `${interaction.member},\n${errorEmoji} **Įvyko klaida vykdant patvirtinimo komandą.**\n\n**Klaidos priežastis:** \`${err}\``, ephemeral: true })

      }

    }
  },
};
