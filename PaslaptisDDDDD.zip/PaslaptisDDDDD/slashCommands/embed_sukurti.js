const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed_sukurti')
    .setDescription('Sukurkite pritaikytą embed žinutę.')
    .addStringOption(option => 
      option.setName('pavadinimas')
        .setDescription('Embed antraštė')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('aprašymas')
        .setDescription('Embed aprašymas')
        .setRequired(true))
    .addStringOption(option => 
      option.setName('pabaiga')
        .setDescription('Embed pabaiga'))
    .addStringOption(option => 
      option.setName('spalva')
        .setDescription('Embed spalva (hex reikšmė, pvz., #FF0000)'))
    .addStringOption(option => 
      option.setName('nuotrauka')
        .setDescription('Embed nuotraukos URL')),

  async execute(client, interaction) {
    const { moderatorRoleId } = require("../config.json"); // Pakeiskite į savo moderatoriaus rolės ID
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole) {
      return console.log("[WARN] Moderatorių rolė neegzistuoja!");
    }

    // Patikrinkite, ar naudotojas turi moderatoriaus rolę
    if (!interaction.member.roles.cache.has(modRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Moderatoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${modRole.id}>`,
        ephemeral: true
      });
    }

    // Gaukite komandos parinktis
    const title = interaction.options.getString('pavadinimas');
    const description = interaction.options.getString('aprašymas');
    const footer = interaction.options.getString('pabaiga');
    const color = interaction.options.getString('spalva') || '#0000FF'; // Numatytoji spalva – mėlyna
    const image = interaction.options.getString('nuotrauka');

    // Sukurkite embed
    const embed = new MessageEmbed()
      .setTitle(title)
      .setDescription(description)
      .setFooter(footer || 'Nėra papildomos informacijos')
      .setColor(color)
      .setImage(image || '');

    // Išsiųskite embed į kanalą
    await interaction.reply({ embeds: [embed] });
  },
};
