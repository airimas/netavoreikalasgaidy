const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageAttachment } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kauliukai')
    .setDescription('Pakvieskite kitą žaidėją ir abu mės kauliukus!')
    .addUserOption(option =>
      option.setName('opponent')
        .setDescription('Žaidėjas, su kuriuo norite mesti kauliuką')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const opponent = interaction.options.getUser('opponent'); // Gauti kitą žaidėją
    const player = interaction.user; // Gauti, kuris įvedė komandą

    if (player.id === opponent.id) {
      return interaction.reply({ content: "Tu negali mesti kauliuko su savimi pačiu! 😜", ephemeral: true });
    }

    // Sukuriame mygtukus, kuriuos vartotojas gali paspausti
    const row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId('accept')
          .setLabel('Priimti')
          .setStyle('SUCCESS')
          .setEmoji("1343157840335994890"), // Custom emoji "Priimti"
        new MessageButton()
          .setCustomId('decline')
          .setLabel('Atšaukti')
          .setStyle('DANGER')
          .setEmoji("1343157854944624650") // Custom emoji "Atšaukti"
      );

    // Išsiunčiame kvietimą su mygtukais
    await interaction.reply({
      content: `${opponent.username}, **${player.username}** kviečia Tave mesti kauliukus! Ar priimsi kvietimą?`,
      components: [row],
    });

    // Sukuriame filtrą ir reaguojame į mygtukų paspaudimus
    const filter = (buttonInteraction) => buttonInteraction.user.id === opponent.id;
    const collector = interaction.channel.createMessageComponentCollector({ filter, time: 15000 }); // Kolektorius, kuris veiks 15 sekundžių

    collector.on('collect', async (buttonInteraction) => {
      if (buttonInteraction.customId === 'accept') {
        // Pirmas žaidėjas rideno
        const rollPlayer = Math.floor(Math.random() * 6) + 1;
        // Antras žaidėjas rideno
        const rollŽmogus = Math.floor(Math.random() * 6) + 1;

        // GIF, kuris rodo kauliuko metimą
        const diceGif = new MessageAttachment('https://i.pinimg.com/originals/75/09/82/750982c4ccc4737e643207f54c40170a.gif'); // Pavyzdinis kauliuko metimo GIF

        await buttonInteraction.update({ 
          content: `🎲 **${player.username}** išrideno **${rollPlayer}** ir **${opponent.username}** išrideno **${rollŽmogus}**!`, 
          files: [diceGif], // Siunčiame GIF
          components: [] 
        });

        let winnerMessage = "";
        if (rollPlayer > rollŽmogus) {
          winnerMessage = `**${player.username}** laimėjo! 🏆`;
        } else if (rollŽmogus > rollPlayer) {
          winnerMessage = `**${opponent.username}** laimėjo! 🏆`;
        } else {
          winnerMessage = "Lygiomis! 🙌";
        }

        // Siunčiame, kas laimėjo
        await buttonInteraction.followUp({ content: winnerMessage });
      } else if (buttonInteraction.customId === 'decline') {
        await buttonInteraction.update({ content: `**${opponent.username}** atsisakė kvietimo žaisti.`, components: [] });
      }
    });

    collector.on('end', async (collected, reason) => {
      if (reason === 'time') {
        // Jeigu laikas baigėsi ir nepaspaudė jokio mygtuko
        await interaction.editReply({ content: `**${opponent.username}** nesugebėjo atsakyti į kvietimą laiku.`, components: [] });
      }
    });
  },
};
