const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('profilio_nuotrauka')
		.setDescription('Parodo naudotojo nuotrauka')
		.addUserOption(option => option.setName('žmogus').setDescription('Vartotojas, kurio nuotrauka norite pamatyti')),
	category: 'slashCommands/economy', // Tai yra svarbus dalykas, kad komanda priklausytų kategorijai
	async execute(client, interaction) {
		// Paima vartotoją, kurio avatarą norima parodyti
		const user = interaction.options.getUser('žmogus') || interaction.user;

		// Sukuriamas embed su avataru
		const avatarEmbed = new MessageEmbed()
			.setTitle(`${user.username} Avataras`)
			.setImage(user.displayAvatarURL({ dynamic: true, size: 512 })) // Gali būti ir kitas dydis, priklauso nuo poreikių
			.setColor('BLUE') // Galima keisti spalvą
			.setFooter(`Prašymas atliktas: ${interaction.user.tag}`)
			.setTimestamp();

		// Atsakymas su avataru
		await interaction.reply({ embeds: [avatarEmbed] });
	},
};
