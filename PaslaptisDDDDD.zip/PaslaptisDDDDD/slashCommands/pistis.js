const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pistis')
    .setDescription('Siūlyk pistis kitam asmeniui!')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirink asmenį, su kuriuo nori pasipist!')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo');
    const sender = interaction.user;

    // Atsitiktinė žinutė
    const response = `**${sender.username}** nori pasipisti su **${targetUser.username}**! 💖`;

    // Pridėti patvirtinimo mygtukus (sutinku / nesutinku)
    const row = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId('sutinku')
        .setLabel('Sutinku')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setCustomId('nesutinku')
        .setLabel('Nesutinku')
        .setStyle('DANGER')
    );

    // Siųsti pirmą atsakymą į sąveiką, kad užtikrintume, jog tai nebus klaida
    await interaction.reply({
      content: `Prašome palaukti, kol **${targetUser.username}** atsakys į sekso pasiūlymą...`,
      ephemeral: true,
    });

    // Siųsti pasiūlymą į tą pačią serverio žinutę su mygtukais
    const channel = interaction.channel;
    const msg = await channel.send({
      content: `**${sender.username}** nori sekso su **${targetUser.username}**! Ar norite sutikti?`,
      components: [row],
    });

    // Užfiksuoti mygtuko paspaudimą tik nuo targetUser
    const filter = i => i.user.id === targetUser.id;
    const collector = channel.createMessageComponentCollector({
      filter,
      time: 15000, // Laiko limitas 15 sek.
    });

    collector.on('collect', async i => {
      if (i.customId === 'sutinku') {
        // GIF pasirinkimai
        const gifs = [
          'https://64.media.tumblr.com/94d0320bf15f585385d1a1639b90f1be/tumblr_nk351bVIlq1s8maa0o1_500.gif', // NSFW GIF 1
          'https://64.media.tumblr.com/b1791a38f54347a20b34323d2b5ef27c/tumblr_nlu3vjrQwK1s8maa0o1_500.gif', // NSFW GIF 2
          'https://imagex1.sx.cdn.live/images/pinporn/2014/05/26/6179419.gif?width=460', // NSFW GIF 3
          'https://morefunforyou.com/wp-content/uploads/2015/03/Valentina-Nappi-In-Massive-Curves-hardcore-sex-GIF.gif', // NSFW GIF 4
          'https://a.im9.eu/xxxgif-hot-dani-jensen-riding-dick-xxx-gif-porn.gif', // NSFW GIF 5
        ];

        // Atsitiktinis GIF pasirinkimas
        const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

        // Sukuriame embed su atsakymu ir GIF
        const embed = new MessageEmbed()
          .setTitle('Sekso akimirka!')
          .setDescription(`**${sender.username}** ir **${targetUser.username}** dabar pisasi! Netrugdykit! 💖`)
          .setColor('RANDOM')
          .setImage(randomGif) // Pridėtas GIF
          .setFooter('Komanda sukurė @krccdm');

        // Atsakome su embed
        await i.update({ content: 'Vaikai, dabar nežiurėkite!', embeds: [embed], components: [] });
      } else if (i.customId === 'nesutinku') {
        await i.update({ content: `**${targetUser.username}** atsisakė gero ir malonaus sekso.`, components: [] });
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        channel.send({
          content: 'Laiko limitas baigėsi. Prašome bandyti dar kartą.',
          components: [],
        });
      }
    });
  },
};
