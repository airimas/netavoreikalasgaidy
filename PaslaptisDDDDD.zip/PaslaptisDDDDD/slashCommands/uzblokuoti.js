const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('užblokuoti')
    .setDescription('Užblokuoti žmogų iš serverio.')
    .addUserOption(option =>
      option.setName('žmogus')
        .setDescription('Žmogus, kurį norite užbaninti.')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('priežastis')
        .setDescription('Priežastis, kodėl norite užbaninti šį žmogų.')
        .setRequired(false)),

  async execute(client, interaction) {
    const banUser = interaction.options.getUser('žmogus');
    const banReason = interaction.options.getString('priežastis') || "Priežastis nenurodyta.";

    // Gauti administratoriaus vaidmenį iš konfigūracijos
    const { moderatorRoleId } = require("../config.json");
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
      return console.log("[WARN] Moderatorių vaidmuo neegzistuoja!");

    if (!interaction.member.roles.cache.has(modRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite **Moderatoriaus** vaidmens, kad galėtumėte naudoti šią komandą.`,
        ephemeral: true
      });
    }

    // Sukuriamas banavimo pranešimas
    const embedBan = new MessageEmbed()
      .setTitle("**Žmogus buvo užbanintas!**")
      .setColor("RED")
      .setDescription(`Žmogus <@${banUser.id}> buvo **užbanintas**.`)
      .addField("ID", `\`${banUser.id}\``, true)
      .addField("Priežastis", `\`${banReason}\``, true)
      .setThumbnail(banUser.displayAvatarURL({ dynamic: true }))
      .setFooter("BAN komanda")
      .setTimestamp();

    try {
      // Baninimas
      await interaction.guild.bans.create(banUser, {
        reason: banReason
      });

      // Sukuriama atgalinė žinutė
      const successEmbed = new MessageEmbed()
        .setTitle("**Užbanintas sėkmingai!**")
        .setColor("GREEN")
        .setDescription(`${banUser.tag} buvo užbanintas sėkmingai iš serverio!`)
        .addField("Žmogaus ID", `\`${banUser.id}\``, true)
        .addField("Priežastis", `\`${banReason}\``, true)
        .setTimestamp()
        .setFooter("BAN komanda");

      // Atsakymas ir embed siunčiamas į kanalą
      await interaction.reply({ content: `**${banUser.tag}** buvo užbanintas sėkmingai!`, ephemeral: true });
      await interaction.channel.send({ embeds: [embedBan] });

    } catch (error) {
      console.error("Klaida užblokuojant žmogų: ", error);

      // Klaidos pranešimas
      const errorEmbed = new MessageEmbed()
        .setTitle("Įvyko klaida!")
        .setDescription(`Deja, **nepavyko užbaninti** žmogaus ${banUser.tag}.`)
        .setColor("RED")
        .setFooter("BAN komanda")
        .setTimestamp();

      await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
    }
  },
};
