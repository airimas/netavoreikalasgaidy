    const { SlashCommandBuilder } = require('@discordjs/builders');
    const { MessageEmbed } = require('discord.js');
    const ms = require('ms'); // Importuojame ms biblioteką, kad galėtume dirbti su laiko intervalais

    module.exports = {
      data: new SlashCommandBuilder()
        .setName('putes_gylis')
        .setDescription('Sužinok kiek į tavo putę tilptų cm!'),

      async execute(client, interaction) {
        // Leistinų rolių ID
        const allowedRoles = ['role_id_1', 'role_id_2']; // Čia įrašykite savo leistinas roles

        // Patikriname, ar naudotojas turi leistiną rolę
        const member = interaction.member;
        const hasPermission = allowedRoles.some(roleId => member.roles.cache.has(roleId));

        if (!hasPermission) {
          return interaction.reply({ content: '**Neturite teisės naudoti šios komandos!**', ephemeral: true });
        }

        // Patikriname, kada paskutinį kartą buvo naudojama ši komanda (1 minutė)
        const lastUsed = await client.db.get(`putes_gylis_used_${interaction.user.id}`);

        if (lastUsed && Date.now() - lastUsed < ms('1m')) {
          const timeRemaining = ms('1m') - (Date.now() - lastUsed);
          return interaction.reply({ content: `**Šią komandą galite naudoti tik kas 1 minutę!** Pabandykite vėl po ${ms(timeRemaining, { long: true })}.`, ephemeral: true });
        }

        // Atsitiktinis skaičius nuo 10 iki 30 (tai tik pavyzdys)
        const length = Math.floor(Math.random() * 21) + 10;

        // Atnaujiname laiką, kada buvo paskutinį kartą naudojama ši komanda
        await client.db.set(`putes_gylis_used_${interaction.user.id}`, Date.now());

        const embed = new MessageEmbed()
          .setTitle('Putes gilumas:')
          .setDescription(`Į tavo pute tilptu \`${length} cm\`! 🦄`)
          .setColor("RANDOM")
          .setFooter('Komanda sukurė @krccdm')
          // Čia įkelkite savo GIF nuorodą
          .setImage('https://media1.giphy.com/media/IdOng61nHYYzuXzbey/giphy.gif?cid=6c09b952wx7iuqhjyzgy3fqwzduulf3287ghw93p0l9cgq8c&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=s');  // Pakeiskite šią nuorodą į savo GIF

        // Atsakome su embed
        return interaction.reply({ embeds: [embed] });
      },
    };
