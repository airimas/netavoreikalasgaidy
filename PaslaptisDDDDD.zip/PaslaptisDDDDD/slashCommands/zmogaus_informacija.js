const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('žmogaus_informacija')
    .setDescription('Rodo informacija apie vartotoją')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirinkite vartotoją, apie kurį norite sužinoti informaciją')
        .setRequired(false) // Jei nebus pasirinkta, bus rodomas vykdytojo informacija
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo') || interaction.user; // Jei asmuo nėra pasirinktas, bus rodomas vykdytojo

    // Užfiksuoti vartotoją su visa informacija
    const member = await interaction.guild.members.fetch(targetUser.id);
    const userAvatar = targetUser.displayAvatarURL({ dynamic: true, size: 1024 });

    // Patikriname, ar vartotojas turi bannerį ir užfiksuojame jį
    let userBanner = 'Nėra bannerio';
    if (targetUser.banner) {
      userBanner = targetUser.bannerURL({ dynamic: true, size: 1024 });
    }

    const accountCreationDate = targetUser.createdAt.toDateString();
    const serverJoinDate = member.joinedAt.toDateString();
    const roles = member.roles.cache.map(role => role.name).join(', ') || 'Nėra rolių';
    const accountStatus = targetUser.presence ? targetUser.presence.status : 'Nėra statuso';

    // Sukuriame embed su vartotojo informacija
    const embed = new MessageEmbed()
      .setTitle(`${targetUser.username} Informacija`)
      .setColor('#3498db')
      .setThumbnail(userAvatar)
      .addFields(
        { name: 'Avataras', value: `[Spustelėkite, kad pamatytumėte](${userAvatar})`, inline: true },
        { name: 'Banneris', value: userBanner === 'Nėra bannerio' ? userBanner : `[Spustelėkite, kad pamatytumėte](${userBanner})`, inline: true },
        { name: 'Paskyros sukūrimo data', value: accountCreationDate, inline: true },
        { name: 'Prisijungimo data į serverį', value: serverJoinDate, inline: true },
        { name: 'Rolės', value: roles, inline: true },
        { name: 'Paskyros ID', value: targetUser.id, inline: true },
        { name: 'Paskyros statusas', value: accountStatus, inline: true }
      )
      .setFooter({ text: 'Komanda sukurta @krccdm' }) // Patikslinome su objektu
      .setTimestamp();

    // Atsakome su embed
    await interaction.reply({ embeds: [embed] });
  },
};
