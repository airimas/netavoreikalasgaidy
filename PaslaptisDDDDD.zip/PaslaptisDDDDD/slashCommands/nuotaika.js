const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('nuotaika')
    .setDescription('Kokia tavo nuotaika šiandien?')
    .addStringOption(option =>
      option.setName('kokia')
        .setDescription('Pasirink savo nuotaiką')
        .setRequired(true)
        .addChoice('Laimingas', 'Laimingas')
        .addChoice('Pavargęs', 'Pavargęs')
        .addChoice('Neramus', 'Neramus')
        .addChoice('Liūdnas', 'Liūdnas')
        .addChoice('Nustebęs', 'Nustebęs')
        .addChoice('Įsimylėjęs', 'Įsimylėjęs')
        .addChoice('Nustebintas', 'Nustebintas')
        .addChoice('Susijaudinęs', 'Susijaudinęs')
        .addChoice('Pasimetęs', 'Pasimetęs')
    ),
  async execute(client, interaction) {
    const mood = interaction.options.getString('kokia');
    let response;
    let imageUrl;

    switch (mood) {
      case 'Laimingas':
        response = [
          'Puiku! Laimė - tavo žaidimo korta šiandien!',
          'Laikykis taip, nuotaikos tik gerės!',
          'Šiandien gali pasiekti viską! Leisk laimei būti tavo vedliu!',
        ];
        imageUrl = 'https://media0.giphy.com/media/2GN4OAIdsMDv10jAVn/giphy.gif?cid=6c09b952cd8i34zbtxf1vlg5qcanr7tperf0a8bcbfvof0mt&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g';  // Laimingas GIF
        break;
      case 'Pavargęs':
        response = [
          'Pailsėk! Rytoj bus geriau.',
          'Atsipūsk, kad galėtum sugrįžti su nauju įkvėpimu!',
          'Nuovargis praeis, o tu būsi stipresnis nei bet kada!',
        ];
        imageUrl = 'https://images.delfi.lt/media-api-image-cropper/v1/b4cca0b0-7974-11ed-bbfd-e17f1d900260.jpg?noup&w=1200&h=711&fx=0.5&fy=0.25';  // Pavargęs GIF
        break;
      case 'Neramus':
        response = [
          'Viskas bus gerai! Pabandyk atsipalaiduoti.',
          'Nebijok, atsikvėpk ir susikaupk – viskas išsispręs!',
          'Nerimas praeis, svarbu tik įkvėpti ir iškvėpti!',
        ];
        imageUrl = 'https://thumb.ac-illust.com/72/7293c0dd37d4e688696a901caef96459_t.jpeg';  // Neramus GIF
        break;
      case 'Liūdnas':
        response = [
          'Būk stiprus! Rytoj laukia nauja diena.',
          'Liūdesys nesitęs amžinai, ir po lietaus ateina saulė!',
          'Uždenk tą liūdesį, nes ateina geresnės dienos!',
        ];
        imageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRN55wy552gnYDZ1yJe7uON4iuOR_GH-0sRyQ&s';  // Liūdnas GIF
        break;
      case 'Nustebęs':
        response = [
          'Kas nutiko?! Atrodo, kad ši diena bus pilna įvykių!',
          'Wow! Tikėtina, kad ši diena tau atneš dar daugiau netikėtumų!',
          'Neišsigąsk, atrodai pasiruošęs priimti šiuos iššūkius!',
        ];
        imageUrl = 'https://as1.ftcdn.net/v2/jpg/03/20/79/96/1000_F_320799612_lcx9eLZaKRjGyFmjlq04Id8ZOBp88Jck.jpg';  // Nustebęs GIF
        break;
      case 'Įsimylėjęs':
        response = [
          'Meilė ore! Nepamiršk, kad meilė prasideda nuo tavęs paties!',
          'Tavo širdis pilna meilės! Užpildyk ją ir toliau!',
          'Meilė yra viskas – šiandien ji dar labiau žydi!',
        ];
        imageUrl = 'https://cff2.earth.com/uploads/2021/02/14062620/72811D47-DA76-4AD1-9B42-1A72954C26EC-scaled.jpeg';  // Įsimylėjęs GIF
        break;
      case 'Nustebintas':
        response = [
          'Oho! Tai atrodo kaip ypatinga diena.',
          'Nustebimas tave tik stiprins, tai tik pradžia!',
          'Šiandien tikrai gali pasiekti naujas aukštumas!',
        ];
        imageUrl = 'https://i0.wp.com/dictionaryblog.cambridge.org/wp-content/uploads/2023/05/shocked.jpg?ssl=1';  // Nustebintas GIF
        break;
      case 'Susijaudinęs':
        response = [
          'Žiauriai įdomu! Ruošiesi kažkam dideliam?',
          'Tavo susijaudinimas gali tapti tavo stiprybe šiandien!',
          'Tai tavo laikas! Eik ir pasiek tai, kas tavęs laukia!',
        ];
        imageUrl = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyw82v34FC4b40w0D_4HuFS-HpxgeikSKfYQ&s';  // Susijaudinęs GIF
        break;
      case 'Pasimetęs':
        response = [
          'Viskas bus gerai! Galbūt reikia padaryti pauzę ir susikoncentruoti.',
          'Pasimetimas yra tik laikinas. Rask savo kelią į priekį!',
          'Nesupranti? Ramiai, viskas susidėlios ir tu rasisi atsakymus!',
        ];
        imageUrl = 'https://media.tenor.com/iSQH4cdR6qoAAAAM/confused-im.gif';  // Pasimetęs GIF
        break;
      default:
        response = [
          'Tavo nuotaika šiandien yra paslaptis!',
          'Kiekviena nuotaika turi savo žavesio, todėl nesijaudink!',
          'Kas bebūtum, šiandien tu esi nepaprastai svarbus!',
        ];
        imageUrl = 'https://media.tenor.com/1QPuexoJxxYAAAAM/secret-boss-baby.gif';  // Atsitiktinis GIF
        break;
    }

    const randomResponse = response[Math.floor(Math.random() * response.length)];

    const embed = new MessageEmbed()
      .setTitle(`Tavo nuotaika šiandien: ${mood.charAt(0).toUpperCase() + mood.slice(1)}`)
      .setDescription(randomResponse)
      .setColor('YELLOW')
      .setImage(imageUrl);  // Pridėti atitinkamą GIF nuorodą

    interaction.reply({ embeds: [embed] });
  },
};
