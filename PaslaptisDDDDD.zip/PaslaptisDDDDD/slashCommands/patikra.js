const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('patikra')
    .setDescription("Patikrinkite atsitiktinį žmogų, ar jis yra pilnametis, ar nepilnametis")
    .addUserOption(option => option.setName('žmogus').setDescription('Žmogus, kurį reikia patikrinti.').setRequired(true)),
  async execute(client, interaction) {

    const { successEmoji } = require("../emojis.json")

      const target = interaction.options.getUser('žmogus');

      const gen = Math.floor(Math.random() * 99) + 1;

      const embed = new MessageEmbed()
      .setTitle("Nepilnamečių Detektorius:")
      .setDescription(`🔞 ${target} yra \`${gen}%\` nepilnametis!`)
      .setColor("RED")
      .setTimestamp();

      await interaction.reply({ embeds: [embed] });

  },
};
