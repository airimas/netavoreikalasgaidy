const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('serverio_informacija')
    .setDescription('Rodo informaciją apie serverį'),
  async execute(client, interaction) {
    const guild = interaction.guild;

    // Tikriname, ar serveris turi banner
    const banner = guild.bannerURL({ dynamic: true }) || null;
    const avatar = guild.iconURL({ dynamic: true }) || null;
    const invite = await guild.fetchVanityData().catch(() => null); // Pakvietimo nuoroda
    const vanityURL = invite ? `https://discord.gg/${invite.code}` : 'Serveris neturi vanity pakvietimo nuorodos';

    // Kanalų skaičiavimas pagal tipus
    const textChannels = guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT').size;
    const voiceChannels = guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE').size;
    const categories = guild.channels.cache.filter(channel => channel.type === 'GUILD_CATEGORY').size;

    const embed = new MessageEmbed()
      .setTitle(`${guild.name} Serverio informacija`)
      .setThumbnail(avatar || 'https://cdn.discordapp.com/embed/avatars/0.png') // Jei nėra avataro, naudoti numatytą
      .setImage(banner || 'https://cdn.discordapp.com/embed/banners/0.png') // Jei nėra bannerio, naudoti numatytą
      .addFields(
        { name: 'Serverio vardas', value: guild.name, inline: true },
        { name: 'ID', value: guild.id, inline: true },
        { name: 'Sukurimo data', value: `<t:${Math.floor(guild.createdTimestamp / 1000)}:D>`, inline: true },
        { name: 'Savininkas', value: `<@${guild.ownerId}>`, inline: true },
        { name: 'Regionas', value: guild.preferredLocale, inline: true },
        { name: 'Narių skaičius', value: `${guild.memberCount} nariai`, inline: true },
        { name: 'Emojiai', value: `${guild.emojis.cache.size} emojai`, inline: true },
        { name: 'Kanalų skaičius', value: `${guild.channels.cache.size} kanalai`, inline: true },
        { name: 'Kategorijų skaičius', value: `${categories} kategorijos`, inline: true },
        { name: 'Teksto kanalų skaičius', value: `${textChannels} tekstiniai kanalai`, inline: true },
        { name: 'Voice kanalų skaičius', value: `${voiceChannels} voice kanalai`, inline: true },
        { name: 'Boost levelis', value: `${guild.premiumTier}`, inline: true },
        { name: 'Boostų skaičius', value: `${guild.premiumSubscriptionCount} boostai`, inline: true },
        { name: 'Pakvietimo nuoroda', value: vanityURL, inline: true }
      )
      .setColor('RANDOM')
      .setFooter({ text: 'Serverio informacija', iconURL: avatar })
      .setTimestamp();

    interaction.reply({ embeds: [embed] });
  },
};
