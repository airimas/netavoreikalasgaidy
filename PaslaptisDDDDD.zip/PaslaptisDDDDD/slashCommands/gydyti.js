const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const ms = require('ms'); // Importuojame ms biblioteką

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gydyti')
    .setDescription('Nuima timeout nuo žaidėjo ir pagydo jį. (Galima naudoti tik kas 1 valandą)')
    .addUserOption(option => option.setName('user').setDescription('Žaidėjas, kuriam bus suteiktas gydymas').setRequired(true)),

  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('user');
    const { successEmoji, errorEmoji } = require("../emojis.json");

    // 5 roles, kurios turi teisę naudoti šią komandą
    const allowedRoles = ['1205932132510466140', '1343318834362449950', 'role_id_3', 'role_id_4', 'role_id_5'];

    // Patikriname, ar komandos vykdytojas turi vieną iš leistinų rolių
    const member = interaction.member;
    const hasPermission = allowedRoles.some(roleId => member.roles.cache.has(roleId));

    if (!hasPermission) {
      return interaction.reply({ content: `${errorEmoji} **Nesate perėje medicinos kursu!**`, ephemeral: true });
    }

    // Patikriname, ar nurodytas naudotojas nėra pats komandos vykdytojas
    if (targetUser.id === interaction.user.id) {
      return interaction.reply({ content: `${errorEmoji} **Negalite pagydyti savęs!**`, ephemeral: true });
    }

    // Patikriname paskutinį kartą, kada buvo naudojama ši komanda (1 valanda)
    const lastUsed = await client.db.get(`gydyti_used_${interaction.user.id}`);

    if (lastUsed && Date.now() - lastUsed < ms('1h')) {
      const timeRemaining = ms('1h') - (Date.now() - lastUsed);
      return interaction.reply({ content: `${errorEmoji} **Šią komandą galite naudoti tik kas 1 valandą!** Pabandykite vėl po ${ms(timeRemaining, { long: true })}.`, ephemeral: true });
    }

    // Gauti GuildMember objektą
    let targetMember;
    try {
      targetMember = await interaction.guild.members.fetch(targetUser.id);
    } catch (err) {
      console.error("Nepavyko gauti targetMember objekto:", err);
      return interaction.reply({ content: `${errorEmoji} **Nepavyko rasti tokio žmogaus!**`, ephemeral: true });
    }

    // Patikriname, ar žaidėjas turi timeout
    if (!targetMember.communicationDisabledUntil) {
      return interaction.reply({ content: `${errorEmoji} **Žaidėjas nėra sužalotas!**`, ephemeral: true });
    }

    // Atšaukiame timeout
    try {
      await targetMember.timeout(null, `Gydyta pagal komandos \`/gydyti\``);

      // Pirmas GIF - gydymas
      const healingGIFs = [
        'https://media0.giphy.com/media/1FqyIw2lMKT2U/giphy.gif?cid=6c09b952uuz9dfarvarfnqpx1ezikkwrgsijk3t3a4f8ro4u&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g', // Giphy GIF
        'https://static.wikia.nocookie.net/tokyoesp/images/a/a9/Healing.gif/revision/latest?cb=20160412055709', // Giphy GIF
        'https://i.pinimg.com/originals/b9/c1/e5/b9c1e51e9af9e71d84cf6c985ec06abf.gif', // Giphy GIF
      ];

      // Pasirenkame atsitiktinį GIF iš sąrašo
      const randomGIF = healingGIFs[Math.floor(Math.random() * healingGIFs.length)];

      const embed = new MessageEmbed()
        .setTitle("Pagydytas žmogus!")
        .setDescription(`**${targetUser.tag}** buvo pagydytas! Jis dabar vėl gali rašyti!`)
        .setColor("GREEN")
        .setFooter({ text: "Komanda sukurė @krccdm", iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp()
        .setImage(randomGIF) // Atsitiktinis GIF
        .addField('Gydymo procesas:', 'Žaidėjas pagydytas, ir vėl gali bendrauti su visais!');

      await interaction.reply({ content: `${successEmoji} **Sėkmingai pagydytas žmogus!**`, embeds: [embed] });

      // Užfiksuojame laiką, kada buvo naudota komanda
      await client.db.set(`gydyti_used_${interaction.user.id}`, Date.now());

    } catch (error) {
      console.error("Klaida vykdant gydymo operaciją:", error);
      return interaction.reply({ content: `${errorEmoji} **Įvyko klaida pagydant žaidėją!**`, ephemeral: true });
    }
  },
};
