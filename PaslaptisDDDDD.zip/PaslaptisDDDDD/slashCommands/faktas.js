const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('faktas_apie_mane')
    .setDescription('Atsitiktinis faktas apie tave!'),
  async execute(client, interaction) {
    const facts = [
      'Tu turi nuostabią asmenybę!',
      'Tavo pasirinkimai visada yra geriausi!',
      'Tu esi labai kūrybingas žmogus!',
      'Niekas nepastebi, bet tavo šypsena gali pakeisti dieną!',
      'Tu nuolat stebini visus savo žiniomis!',
      'Tavo humoro jausmas niekada nesibaigia!',
      'Tu turi stiprų ryšį su savo draugais ir šeima!',
      'Tavo gebėjimas išspręsti problemas yra įspūdingas!',
      'Visi žino, kad gali pasitikėti tavimi!',
      'Tu esi tikras lyderis, kuris įkvepia kitus!',
      'Tu turi nepaprastą kantrybę ir ištvermę!',
      'Tavo atsidavimas visada padeda pasiekti tikslus!',
      'Tu sugebi matyti pasaulį pozityviai, net ir sunkiausiais laikais!',
      'Tavo kūrybiškumas neprilygsta niekam kitam!',
      'Tavo gebėjimas klausytis ir suprasti kitus yra nuostabus!',
      'Visi tavęs vertina už tavo nuoširdumą ir dosnumą!',
      'Tavo drąsa siekti savo tikslų yra įkvepianti!',
      'Tu niekada nepasiduodi, nesvarbu kokios kliūtys!',
      'Tavo noras padėti kitiems yra tikras bruožas!',
      'Tu visada randi būdų, kaip išspręsti sudėtingas situacijas!',
      'Tavo gebėjimas džiaugtis mažais dalykais daro tave ypatingu!',
      'Tavo pasitikėjimas savimi skatina ir kitus būti drąsesniais!',
      'Tavo optimizmas padeda atlaikyti net sunkiausias dienas!',
      'Tavo gebėjimas daryti kitus laimingus yra neįkainojamas!',
      'Tu nuolat ieškai naujų būdų tobulėti ir augti!',
      'Tavo nuoširdus dėmesys kitiems yra labai vertinamas!',
      'Tavo entuziazmas užkrečia visus aplinkinius!',
      'Tu sugebi išlaikyti ramybę net ir įtemptose situacijose!',
      'Tavo pastangos ir darbštumas visada atsiperka!',
      'Tu esi žmogus, kuris žino, kaip pasiekti savo tikslus!',
      'Tavo žingeidumas ir noras sužinoti daugiau yra nuostabus!',
      'Tu visada žinai, kaip įkvėpti kitus tikėti savo svajonėmis!',
      'Tu sugebi padėti kitiems, net kai pats turi savo rūpesčių!',
      'Tavo išskirtinis požiūris į gyvenimą yra vertinamas!',
      'Tavo nuoširdumas ir atvirumas yra tai, kas tave daro ypatingu!',
      'Tavo gera širdis ir dosnumas palieka pėdsaką visur, kur nueini!',
      'Tu sugebi išspręsti bet kokią problemą su lengvumu!',
      'Tavo gebėjimas būti kantriam ir užsispyrusiam padeda pasiekti didelių dalykų!',
      'Tu esi nuostabus žmogus, kuris nuolat daro pasaulį geresnį!',
      'Tavo atsakomybė ir atsidavimas padeda siekti tikslų, nesustojant!'
    ];

    const fact = facts[Math.floor(Math.random() * facts.length)];

    const embed = new MessageEmbed()
      .setTitle('Atsitiktinis faktas apie tave!')
      .setDescription(fact)
      .setColor('BLUE');

    interaction.reply({ embeds: [embed] });
  },
};
