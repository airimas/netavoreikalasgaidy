const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bučkis')
    .setDescription('Siūlyk bučiuotis kitam asmeniui')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirink asmenį, su kuriuo nori pasibučiuoti')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo');
    const sender = interaction.user;

    // Atsitiktinė žinutė
    const response = `**${sender.username}** nori pasibučiuoti **${targetUser.username}**! 💖`;

    // Pridėti patvirtinimo mygtukus (sutinku / nesutinku)
    const row = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId('sutinku')
        .setLabel('Sutinku')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setCustomId('nesutinku')
        .setLabel('Nesutinku')
        .setStyle('DANGER')
    );

    // Siųsti pirmą atsakymą į sąveiką, kad užtikrintume, jog tai nebus klaida
    await interaction.reply({
      content: `Prašome palaukti, kol **${targetUser.username}** atsakys į bučkio pasiūlymą...`,
      ephemeral: true,
    });

    // Siųsti pasiūlymą į tą pačią serverio žinutę su mygtukais
    const channel = interaction.channel;
    const msg = await channel.send({
      content: `**${sender.username}** nori pasibučiuoti **${targetUser.username}**! Ar norite sutikti?`,
      components: [row],
    });

    // Užfiksuoti mygtuko paspaudimą tik nuo targetUser
    const filter = i => i.user.id === targetUser.id;
    const collector = channel.createMessageComponentCollector({
      filter,
      time: 15000, // Laiko limitas 15 sek.
    });

    collector.on('collect', async i => {
      if (i.customId === 'sutinku') {
        // GIF pasirinkimai
        const gifs = [
          'https://24.media.tumblr.com/tumblr_madyj5Fa6m1rq4lc6o1_500.gif', // KISS GIF 1
          'https://media1.tenor.com/m/H0Pp6l_7fmwAAAAC/couple-kiss-couple-kissing.gif', // KISS GIF 2
          'https://media1.giphy.com/media/perRo4txxsFxe/giphy.gif?cid=6c09b952janm7pxrh1bfsd3qfl8bv6ldyaf2ajlclg52jz59&ep=v1_gifs_search&rid=giphy.gif&ct=g', // KISS GIF 3
          'https://i.gifer.com/1uSe.gif', // KISS GIF 4
          'https://media2.giphy.com/media/6beiVuEiW21Vm6eZdV/giphy.gif?cid=6c09b952wnj45htok5ovse3e2gptkxbpr8drwuc41d5069rf&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g', // KISS GIF 5
        ];

        // Atsitiktinis GIF pasirinkimas
        const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

        // Sukuriame embed su atsakymu ir GIF
        const embed = new MessageEmbed()
          .setTitle('Bučinio akimirka!')
          .setDescription(`**${sender.username}** ir **${targetUser.username}** dabar pabučiuoja vienas kitą! 💖`)
          .setColor('RANDOM')
          .setImage(randomGif) // Pridėtas GIF
          .setFooter('Komanda sukurė @krccdm');

        // Atsakome su embed
        await i.update({ content: 'Smagaus bučinio!', embeds: [embed], components: [] });
      } else if (i.customId === 'nesutinku') {
        await i.update({ content: `**${targetUser.username}** atsisakė bučiuotis.`, components: [] });
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        channel.send({
          content: 'Laiko limitas baigėsi. Prašome bandyti dar kartą.',
          components: [],
        });
      }
    });
  },
};
