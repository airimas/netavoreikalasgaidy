const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('penio_cm')
    .setDescription('Sužinok, kokio ilgio tavo pimpalas!'),

  async execute(client, interaction) {
    // Leidžiamos roles - įrašykite savo rolės ID čia
    const allowedRoles = ['role_id_1', 'role_id_2']; // Pakeiskite su realiais role ID, kuriems bus leidžiama naudoti komandą

    // Patikriname, ar naudotojas turi leidžiamą rolę
    const member = interaction.member;
    const hasPermission = allowedRoles.some(roleId => member.roles.cache.has(roleId));

    if (!hasPermission) {
      return interaction.reply({ content: '**Neturite teisės naudoti šios komandos!**', ephemeral: true });
    }

    const cooldownTime = 60000; // 1 minutė (60 000 ms)
    const userId = interaction.user.id;

    // Nustatome laiką, kada komanda buvo paskutinį kartą naudota
    const now = Date.now();
    const lastUsed = await client.db.get(`penisCooldown_${userId}`); // Naudojame bazę (pvz. SQLite, MongoDB ar pan.)

    // Jei komanda buvo naudojama per mažiau nei 1 minutę
    if (lastUsed && now - lastUsed < cooldownTime) {
      const timeLeft = cooldownTime - (now - lastUsed); // Laiko skirtumas iki kito naudojimo
      const minutesLeft = Math.ceil(timeLeft / 60000); // Laiko skirtumas minutėmis

      return interaction.reply({
        content: `Galite naudoti šią komandą tik po ${minutesLeft} minutės!`,
        ephemeral: true
      });
    }

    // Atsitiktinis skaičius nuo 10 iki 30 (tai tik pavyzdys)
    const length = Math.floor(Math.random() * 21) + 10;

    // GIF nuoroda, kuri bus pridėta
    const gifUrl = 'https://media1.giphy.com/media/IdOng61nHYYzuXzbey/giphy.gif?cid=6c09b952wx7iuqhjyzgy3fqwzduulf3287ghw93p0l9cgq8c&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=s'; // Čia galite pakeisti savo GIF nuorodą

    // Sukuriame embed su ilgiu
    const embed = new MessageEmbed()
      .setTitle('Penio ilgis:')
      .setDescription(`Tavo pimpalo ilgis \`${length} cm\`! 🦄`)
      .setColor("RANDOM")
      .setFooter('Komanda sukurė @krccdm')
      .setImage(gifUrl); // Pridėkite GIF nuorodą

    // Atsakome su embed ir atnaujiname paskutinio naudojimo laiką
    await interaction.reply({ embeds: [embed] });
    await client.db.set(`penisCooldown_${userId}`, now); // Išsaugome paskutinio naudojimo laiką į DB
  },
};
