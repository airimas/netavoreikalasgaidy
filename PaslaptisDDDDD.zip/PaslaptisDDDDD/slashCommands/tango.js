const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('tango')
    .setDescription('Pasiūlyk šokti tango kitam asmeniui!')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirink asmenį, su kuriuo nori šokti tango!')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo');
    const sender = interaction.user;

    // Atsitiktinė žinutė
    const response = `**${sender.username}** siūlo **${targetUser.username}** šokti tango! 💃🕺`;

    // Pridėti patvirtinimo mygtukus (sutinku / nesutinku)
    const row = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId('sutinku')
        .setLabel('Sutinku')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setCustomId('nesutinku')
        .setLabel('Nesutinku')
        .setStyle('DANGER')
    );

    // Siunčiame patvirtinimo klausimą su mygtukais
    await interaction.reply({
      content: `Ar tikrai norite šokti tango su **${sender.username}**?`,
      components: [row],
    });

    // Užfiksuoti mygtuko paspaudimą
    const filter = i => i.user.id === targetUser.id; // Užtikriname, kad tik pasirinktas asmuo gali atsakyti
    const collector = interaction.channel.createMessageComponentCollector({
      filter,
      time: 15000, // Laiko limitas 15 sek.
    });

    collector.on('collect', async i => {
      if (i.customId === 'sutinku') {
        // GIF pasirinkimai
        const gifs = [
          'https://media0.giphy.com/media/TLJ0K6vf5KV4xxZyDz/giphy.gif?cid=6c09b952pe1qrqn8zjek8jb917qdmrpacya5fxola8iz91g0&ep=v1_gifs_search&rid=giphy.gif&ct=g', // Tango GIF
          'https://img1.picmix.com/output/pic/normal/7/5/2/4/8564257_9d0ed.gif', // Tango GIF
          'https://media3.giphy.com/media/v8OMQSKtqcnPG/giphy.gif?cid=6c09b952954oh5czw660ovexxfpbmixyb5nl2pjpqa8u1glm&ep=v1_gifs_search&rid=giphy.gif&ct=g', // Tango GIF
          'https://media0.giphy.com/media/ak3UmUjuGlQdi/giphy.gif?cid=6c09b952muo0n1cijpt8r18heuh29cyqjde3foebnok4p1v3&ep=v1_gifs_search&rid=giphy.gif&ct=g', // Tango GIF
          'https://i2.kknews.cc/Iy21BI73PnPhjoPsZgy9qa_7bVVULwVDIw/0.jpg', // Tango GIF
        ];

        // Atsitiktinis GIF pasirinkimas
        const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

        // Sukuriame embed su atsakymu ir GIF
        const embed = new MessageEmbed()
          .setTitle('Tango šokis! 💃🕺')
          .setDescription(response)
          .setColor('RANDOM')
          .setImage(randomGif) // Pridėtas GIF
          .setFooter('Komanda sukurė @krccdm');

        // Atsakome su embed
        await i.update({ content: 'Smagaus šokio!', embeds: [embed], components: [] });
      } else if (i.customId === 'nesutinku') {
        await i.update({ content: '**@user** nusprendė nešokti tango šiandien. 🤷‍♂️', components: [] });
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        interaction.followUp({
          content: 'Laiko limitas baigėsi. Prašome bandyti dar kartą.',
          components: [],
        });
      }
    });
  },
};
