const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('išmesti')
    .setDescription('Pašalinkite žmogų iš serverio.')
    .addUserOption(option => 
      option.setName('žmogus')
        .setDescription('Žmogus, kurį norite pašalinti.')
        .setRequired(true))
    .addStringOption(option =>
      option.setName('priežastis')
        .setDescription('Priežastis, kodėl pašalinote žmogų.')
        .setRequired(false)),

  async execute(client, interaction) {
    const { moderatorRoleId } = require("../config.json");
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole) {
      return console.log("[WARN] Moderatorių rolė neegzistuoja!");
    }

    // Patikriname, ar naudotojas turi moderatoriaus rolę
    if (!interaction.member.roles.cache.has(modRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Moderatoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${modRole.id}>`,
        ephemeral: true
      });
    }

    const target = interaction.options.getUser('žmogus');
    const reason = interaction.options.getString('priežastis') || 'Nepriklauso prie taisyklių'; // Jei nėra priežasties, įrašysime numatytąją

    // Patikriname, ar vartotojas nėra bot
    if (target.bot) {
      return interaction.reply({
        content: 'Negalite pašalinti bot\'o iš serverio.',
        ephemeral: true
      });
    }

    // Patikriname, ar bandomas pašalinti vartotojas nėra pats komandos vykdytojas
    if (target.id === interaction.user.id) {
      return interaction.reply({
        content: 'Negalite pašalinti savęs iš serverio!',
        ephemeral: true
      });
    }

    // Patikriname, ar tikrai turime pakankamai leidimų pašalinti vartotoją
    const member = interaction.guild.members.cache.get(target.id);
    if (!member.kickable) {
      return interaction.reply({
        content: 'Negalite pašalinti šio žmogaus iš serverio. Įsitikinkite, kad jūsų rolė yra aukščiau nei jo.',
        ephemeral: true
      });
    }

    // Pašalinimas ir embed žinutė
    try {
      await member.kick(reason);

      const embed = new MessageEmbed()
        .setColor('#FF0000')
        .setTitle('Žmogus pašalintas!')
        .setDescription(`**Žmogus:** ${target.tag}\n**Priežastis:** ${reason}`)
        .setFooter(`Pašalino ${interaction.user.tag}`, interaction.user.displayAvatarURL())
        .setTimestamp();

      // Siųskite pranešimą į kanalą
      await interaction.reply({
        content: `Žmogus **${target.tag}** buvo pašalintas iš serverio!`,
        embeds: [embed]
      });
    } catch (error) {
      console.error(error);
      return interaction.reply({
        content: 'Įvyko klaida bandant pašalinti šį vartotoją.',
        ephemeral: true
      });
    }
  },
};
