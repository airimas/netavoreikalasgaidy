const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sprogdinti')
    .setDescription('Ištrinkite ir perkurkite kanalą.')
    .addChannelOption(option => option.setName('kanalas').setDescription('ĮSPĖJIMAS: Negalima naikinti svarbių kanalų, tokių kaip #taisykles, #naujienos!').setRequired(true)),

  async execute(client, interaction) {
    const { adminRoleId } = require("../config.json");
    const { loadingEmoji, successEmoji } = require("../emojis.json");
    const adminRole = interaction.guild.roles.cache.find(role => role.id === adminRoleId);

    if (!adminRole) {
      return console.log("[WARN] Administratoriaus rolė neegzistuoja!");
    }

    // Patikrinkite, ar vartotojas turi administratoriaus rolę
    if (!interaction.member.roles.cache.has(adminRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Administratoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${adminRole.id}>`,
        ephemeral: true
      });
    }

    // Gaukite pasirinkta kanalą
    const channelToNuke = interaction.options.getChannel('kanalas');
    interaction.reply(`${loadingEmoji} **Nukenksminama ${channelToNuke}...**`);

    // Išsaugome kanalo poziciją
    const position = channelToNuke.position;

    // Sukuriame kopiją ir pašaliname seną kanalą
    const newChannel = await channelToNuke.clone();
    await channelToNuke.delete();
    newChannel.setPosition(position);

    // Sukuriame gražų embed pranešimą
    const embed = new MessageEmbed()
      .setTitle("Kanalas nukenksmintas!")
      .setDescription(`Nukenksmino: ${interaction.member} (${interaction.id})`)
      .setImage("https://media1.tenor.com/images/e275783c9a40b4551481a75a542cdc79/tenor.gif?itemid=3429833")
      .setColor("BLUE")
      .setTimestamp();

    // Siunčiame pranešimą į naują kanalą
    await newChannel.send({ embeds: [embed] });

    // Galutinis atsakymas
    interaction.followUp({ content: `${successEmoji} **Kanalo nukenksminimas baigtas!**`, ephemeral: true });
  },
};
