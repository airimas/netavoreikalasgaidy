const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('apkabinti')
    .setDescription('Siūlyk apkabinimą kitam asmeniui')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirink asmenį, kurį nori apkabinti')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo');
    const sender = interaction.user;

    // Atsitiktinė žinutė
    const response = `**${sender.username}** nori apkabinti **${targetUser.username}**! 💖`;

    // Pridėti patvirtinimo mygtukus (sutinku / nesutinku)
    const row = new MessageActionRow().addComponents(
      new MessageButton()
        .setCustomId('sutinku')
        .setLabel('Sutinku')
        .setStyle('SUCCESS'),
      new MessageButton()
        .setCustomId('nesutinku')
        .setLabel('Nesutinku')
        .setStyle('DANGER')
    );

    // Siųsti pirmą atsakymą į sąveiką, kad užtikrintume, jog tai nebus klaida
    await interaction.reply({
      content: `Prašome palaukti, kol **${targetUser.username}** atsakys į apkabinimo pasiūlymą...`,
      ephemeral: true,
    });

    // Siųsti pasiūlymą į tą pačią serverio žinutę su mygtukais
    const channel = interaction.channel;
    const msg = await channel.send({
      content: `**${sender.username}** nori apkabinti **${targetUser.username}**! Ar norite sutikti?`,
      components: [row],
    });

    // Užfiksuoti mygtuko paspaudimą tik nuo targetUser
    const filter = i => i.user.id === targetUser.id;
    const collector = channel.createMessageComponentCollector({
      filter,
      time: 15000, // Laiko limitas 15 sek.
    });

    collector.on('collect', async i => {
      if (i.customId === 'sutinku') {
        // GIF pasirinkimai
        const gifs = [
          'https://i.pinimg.com/originals/02/2a/19/022a19f8ad9260b5045e16289e66c903.gif', // HUG GIF 1
          'https://i.gifer.com/ZRLK.gif', // HUG GIF 2
          'https://media0.giphy.com/media/wzKg3NoX4Rmc8/giphy.gif?cid=6c09b952svjale99jqjyrbgyuvgsj9w2ocoln984yvw9wy9e&ep=v1_gifs_search&rid=giphy.gif&ct=g', // HUGGIF 3
          'https://www.icegif.com/wp-content/uploads/2023/07/icegif-330.gif', // HUG GIF 4
          'https://media4.giphy.com/media/KG5oq4vesf9r8JbBEN/giphy.gif?cid=6c09b952slxuz6qiie2y0du1156j3c748s0ws5vnlf6ybd8r&ep=v1_gifs_search&rid=giphy.gif&ct=g', // GIF 5
        ];

        // Atsitiktinis GIF pasirinkimas
        const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

        // Sukuriame embed su atsakymu ir GIF
        const embed = new MessageEmbed()
          .setTitle('Apkabinimo akimirka!')
          .setDescription(`**${sender.username}** ir **${targetUser.username}** dabar apkabina vienas kitą! 💖`)
          .setColor('RANDOM')
          .setImage(randomGif) // Pridėtas GIF
          .setFooter('Komanda sukurė @krccdm');

        // Atsakome su embed
        await i.update({ content: 'Smagaus apsikabinimo!', embeds: [embed], components: [] });
      } else if (i.customId === 'nesutinku') {
        await i.update({ content: `**${targetUser.username}** atsisakė apkabinimo.`, components: [] });
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        channel.send({
          content: 'Laiko limitas baigėsi. Prašome bandyti dar kartą.',
          components: [],
        });
      }
    });
  },
};
