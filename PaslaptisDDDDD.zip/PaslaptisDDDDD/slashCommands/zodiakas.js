const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('zodiakas')
    .setDescription('Koks tavo zodiako ženklas šiandien?')
    .addStringOption(option =>
      option.setName('tavo_zodiakas')
        .setDescription('Įvesk savo zodiako ženklą')
        .setRequired(true)
        .addChoice('Avinas', 'Avinas')
        .addChoice('Jautis', 'Jautis')
        .addChoice('Dvyniai', 'Dvyniai')
        .addChoice('Vėžys', 'Vėžys')
        .addChoice('Liūtas', 'Liūtas')
        .addChoice('Mergelė', 'Mergelė')
        .addChoice('Svarstyklės', 'Svarstyklės')
        .addChoice('Skorpionas', 'Skorpionas')
        .addChoice('Šaulys', 'Šaulys')
        .addChoice('Ožiaragis', 'Ožiaragis')
        .addChoice('Vandenis', 'Vandenis')
        .addChoice('Žuvys', 'Žuvys')
    ),
  async execute(client, interaction) {
    const tavo_zodiakas = interaction.options.getString('tavo_zodiakas');

    let horoscope;

    // Zodiako ženklų prognozės
    switch (tavo_zodiakas) {
      case 'Avinas':
        horoscope = `Šiandien Avinas atneš daug naujų galimybių. Būk pasiruošęs veikti greitai ir ryžtingai. Jei pasitikėsi savo intuicija, gali pasiekti neįtikėtinų rezultatų! Tu turi daug energijos, todėl pasinaudok ja veikti!`;
        break;
      case 'Jautis':
        horoscope = `Jautis šiandien gali susidurti su iššūkiais darbe, tačiau kantrybė ir atkaklumas padės įveikti sunkumus. Atmink, kad tai, ką pasodinsi, greitai ir užderės! Nesustok, net jei kelias atrodo sunkus.`;
        break;
      case 'Dvyniai':
        horoscope = `Dvyniams šiandien palankios dienos kalboms ir bendravimui. Tai puikus metas susitikti su senais draugais ir užmegzti naujas pažintis. Atsidavimas savo idėjoms atneš sėkmę. Laikykis atviros širdies!`;
        break;
      case 'Vėžys':
        horoscope = `Vėžys šiandien gali pasijausti šiek tiek jautrus, bet tai suteiks galimybę pasikalbėti su artimaisiais ir užmegzti gilų ryšį. Tai puiki diena atsipalaiduoti ir praleisti laiką su šeima. Tikėk, kad tavo emocijos neša gilią prasmę.`;
        break;
      case 'Liūtas':
        horoscope = `Liūtas šiandien spinduliuos charizmą ir pasitikėjimą savimi. Diena bus kupina galimybių, kuriose galėsi parodyti savo lyderio savybes. Pasitikėk savimi ir nepraleisk galimybės pasirodyti geriausiai!`;
        break;
      case 'Mergelė':
        horoscope = `Mergelė šiandien gali jaustis šiek tiek nerami dėl darbų. Tačiau neprarask vilties – tavo dėmesys detalėms ir kruopštumas atneš rezultatus, kurių laukėte. Gali rasti sprendimus, kur kitus vargina nesėkmės.`;
        break;
      case 'Svarstyklės':
        horoscope = `Svarstyklėms šiandien pasiseks pasiekti pusiausvyrą tiek profesinėje, tiek asmeninėje srityje. Tai puikus metas spręsti senas problemas ir pasiekti harmoniją. Išlaikyti ramybę šią dieną bus lengviau nei bet kada!`;
        break;
      case 'Skorpionas':
        horoscope = `Skorpionui šiandien teks pasirinkti – pasitikėti savo instinktais arba leisti kitiems daryti sprendimus. Svarbu išlaikyti balansą tarp ambicijų ir emocijų. Net jei situacija atrodo sunki, tavo stiprybė neabejotinai padės!`;
        break;
      case 'Šaulys':
        horoscope = `Šaulys šiandien bus labai entuziastingas dėl naujų projektų ir idėjų. Pasiruošk naujoms kelionėms, tiek fiziškai, tiek protiškai! Naujų galimybių laukia už kiekvieno kampo, tik nepamiršk mėgautis šiuo momentu!`;
        break;
      case 'Ožiaragis':
        horoscope = `Ožiaragis šiandien gali turėti daug darbų, tačiau pasitikėk savo gebėjimais ir nesustos – tai gali būti žingsnis į didelę sėkmę! Panaudok savo ambicijas, kad pasiektum ilgalaikius tikslus.`;
        break;
      case 'Vandenis':
        horoscope = `Vandenis šiandien bus labai kūrybingas ir pilnas naujų idėjų. Atmink, kad tavo mintys gali padėti kitiems, tad nebūk bailus jas pasidalinti. Nauji atradimai šiandien laukia tavęs, pasinaudok šia galimybe!`;
        break;
      case 'Žuvys':
        horoscope = `Žuvims šiandien gali prireikti šiek tiek laiko sau, kad atsikvėptų ir atsistatytų. Leisk sau būti kūrybingam ir pasinerti į vidinį pasaulį. Atsipalaidavimas ir kūrybiškumas yra tavo šaltinis šiandien!`;
        break;
      default:
        horoscope = "Šiandienos prognozė nėra pasiekiama. Bandyk vėl vėliau!";
        break;
    }

    // Sukuriame embed su horoskopu
    const embed = new MessageEmbed()
      .setTitle(`Zodiako ženklas: ${tavo_zodiakas}`)
      .setDescription(horoscope)
      .setColor("BLUE")
      .setTimestamp()
      .setFooter("Daugiau sužinosi kitą kartą!");

    interaction.reply({ embeds: [embed] });
  },
};
