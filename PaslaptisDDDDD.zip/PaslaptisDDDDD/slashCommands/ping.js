const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Parodo boto ping (atsako laiką).'),

  async execute(client, interaction) {
    const ping = Date.now() - interaction.createdTimestamp; // Apskaičiuojame atsako laiką

    // Atsakymas su boto ping
    await interaction.reply({
      content: `Pong! 🏓 Boto ping: ${ping}ms`, // Išvedame pingą milisekundėmis
      ephemeral: true, // Tai užtikrina, kad atsakymas bus matomas tik vartotojui, kuris vykdė komandą
    });
  },
};
