const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pačiulpti_bybi')
    .setDescription('Pačiulpk bybi kitam žmogui!')
    .addUserOption(option =>
      option.setName('asmuo')
        .setDescription('Pasirink asmenį, kuriam nori čiulpti')
        .setRequired(true)
    ),
  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('asmuo');
    const sender = interaction.user;

    // Atsitiktinė žinutė
    const response = `**${sender.username}** pačiulpė **${targetUser.username}** bybi! 💖`;

    // GIF pasirinkimai
    const gifs = [
      'https://russmus.net/wp-content/uploads/2024/02/blowjob-gif-30.gif', // NSFW GIF
      'https://static-ca-cdn.eporner.com/gallery/Pa/Lo/MdY8A26LoPa/14500084-39169.gif', // NSFW GIF
      'https://imagex1.sx.cdn.live/images/pinporn/2017/05/20/17791686.gif?width=460', // NSFW GIF
      'https://69.media.tumblr.com/8e0cdff35d6be31b9127d484b9eaf280/tumblr_nf2urktUOE1u3d5tbo1_500.gif', // NSFW GIF
      'https://myteenwebcam.com/fapp/gifs/4a69ad72d3301631ab405b9f928efbc8.gif', // NSFW GIF
    ];

    // Atsitiktinis GIF pasirinkimas
    const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

    // Sukuriame embed su atsakymu ir GIF
    const embed = new MessageEmbed()
      .setTitle('Bybio čiulpimas!')
      .setDescription(response)
      .setColor('RANDOM')
      .setImage(randomGif) // Pridėtas GIF
      .setFooter('Komanda sukurė @krccdm');

    // Atsakome su embed
    await interaction.reply({ embeds: [embed] });
  },
};
