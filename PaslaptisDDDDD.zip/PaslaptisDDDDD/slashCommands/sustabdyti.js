const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js")

module.exports = {
  data: new SlashCommandBuilder()
    .setName('sustabdyti')
    .setDescription('Sustabdyti botą. [Tik ekstremalioms situacijoms]')
    .addStringOption(option =>
    option.setName('pasirinkit')
      .setDescription('Ar tikrai norite sustabdyti botą?')
      //.setRequired(true)
      .addChoice('Taip', 'Taip')
      .addChoice('Ne', 'Ne')),
  async execute(client, interaction) {

    const value = interaction.options.getString('pasirinkit');

    const { adminRoleId } = require("../config.json")
    const { errorEmoji, successEmoji } = require("../emojis.json")
    const adminRole = interaction.guild.roles.cache.find(role => role.id === adminRoleId);

    if (!adminRole)
    return console.log("[WARN] Administratorius rolė neegzistuoja!");

    if (!interaction.member.roles.cache.has(adminRole.id)) { interaction.reply({ content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Administratoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${adminRole.id}>`, ephemeral: true })

    } else {

      if(!value){
      await interaction.reply({ content: `${errorEmoji} Ar tikrai to norite? Naudokite **TAIP** arba **NE.**`, ephemeral: true })
      }

      if(value === "Taip"){
        interaction.reply({ content: `${successEmoji} **Botas buvo sustabdytas.**`, ephemeral: true })
        interaction.channel.send({ content: "👋 Atsisveikiname, pasauli!"}).then(() => process.exit())
      } else {
        interaction.reply({ content: `${successEmoji} **Botas nebus sustabdytas.**`, ephemeral: true })
      }

    }
  },
};
