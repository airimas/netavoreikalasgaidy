const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('parašyti')
    .setDescription('Siųskite tiesioginę žinutę vartotojui.')
    .addUserOption(option => option.setName('žmogus').setDescription('Vartotojas, kuriam bus siunčiama žinutė.').setRequired(true))
    .addStringOption(option => option.setName('žinutė').setDescription('Žinutė').setRequired(true)),

  async execute(client, interaction) {
    const { moderatorRoleId } = require("../config.json");
    const { successEmoji, errorEmoji } = require("../emojis.json");
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
      return console.log("[WARN] Moderatorių rolė neegzistuoja!");

    if (!interaction.member.roles.cache.has(modRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Moderatoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${modRole.id}>`,
        ephemeral: true
      });
    } else {
      const target = interaction.options.getUser('žmogus');  // Naudojame 'žmogus' vietoj 'user'
      const message = interaction.options.getString('žinutė'); // Naudojame 'žinutė' vietoj 'message'

      if (!target) {
        return interaction.reply({
          content: `${errorEmoji} **Vartotojas nebuvo nurodytas!**`,
          ephemeral: true
        });
      }

      if (target.bot) {
        return interaction.reply({
          content: `${errorEmoji} **Negaliu siųsti žinutės bot'ui per tiesiogines žinutes dėl API klaidos!**`,
          ephemeral: true
        });
      }

      const embed = new MessageEmbed()
        .setAuthor(`Jūs gavote žinutę iš ${interaction.guild.name}:`)
        .addFields(
          { name: "Moderatorius:", value: `\`(Slapta)\`` },
          { name: "Žinutė:", value: `${message}` },
        )
        .setColor("BLUE")
        .setFooter({ text: "Ačiū už palaikymą!" });

      target.send({ embeds: [embed] }).catch(() => interaction.channel.send({
        content: `<@${interaction.member.id}>, \n${errorEmoji} **Nepavyko išsiųsti žinutės vartotojui.**\n\nĮprastos priežastys:\n\`•\` Išjungti tiesioginiai pranešimai.\n\`•\` Vartotojas yra bot'as. (Bot'ai negali siųsti žinučių kitiems bot'ams)`
      }));

      interaction.reply({ content: `${successEmoji} **Atlikta!**`, ephemeral: true });
    }
  },
};
