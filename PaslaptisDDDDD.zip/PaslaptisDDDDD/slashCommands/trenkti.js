const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require('discord.js');
const ms = require('ms'); // Importuojame ms biblioteką, kad galėtume dirbti su laiko intervalais

module.exports = {
  data: new SlashCommandBuilder()
    .setName('trenkti')
    .setDescription('Trenkia žaidėjui atsitiktinį timeout nuo 5 iki 30 minučių. (Galima naudoti tik kas 1 valandą)')
    .addUserOption(option => option.setName('user').setDescription('Žaidėjas, kuriam bus suteiktas timeout').setRequired(true)),

  async execute(client, interaction) {
    const targetUser = interaction.options.getUser('user');
    const { successEmoji, errorEmoji } = require("../emojis.json");

    // 5 roles, kurios turi teisę naudoti šią komandą
    const allowedRoles = ['1205932132510466140', '1343318834362449950', 'role_id_3', 'role_id_4', 'role_id_5'];

    // Patikriname, ar komandos vykdytojas turi vieną iš leistinų rolių
    const member = interaction.member;
    const hasPermission = allowedRoles.some(roleId => member.roles.cache.has(roleId));

    if (!hasPermission) {
      return interaction.reply({ content: `${errorEmoji} **Neturite teisių naudoti šią komandą!**`, ephemeral: true });
    }

    // Patikriname, ar nurodytas naudotojas nėra pats komandos vykdytojas
    if (targetUser.id === interaction.user.id) {
      return interaction.reply({ content: `${errorEmoji} **Negalite trenkti sau!**`, ephemeral: true });
    }

    // Patikriname paskutinį kartą, kada buvo naudojama ši komanda (1 valanda)
    const lastUsed = await client.db.get(`trenkti_used_${interaction.user.id}`);

    if (lastUsed && Date.now() - lastUsed < ms('1h')) {
      const timeRemaining = ms('1h') - (Date.now() - lastUsed);
      return interaction.reply({ content: `${errorEmoji} **Šią komandą galite naudoti tik kas 1 valandą!** Pabandykite vėl po ${ms(timeRemaining, { long: true })}.`, ephemeral: true });
    }

    // Generuojame atsitiktinį timeout laiką nuo 5 iki 30 minučių
    const randomTimeout = Math.floor(Math.random() * (30 - 5 + 1)) + 5; // 5 - 30 minutės
    const timeoutInMs = randomTimeout * 60 * 1000; // Paverčiame į milisekundes

    // Gauti GuildMember objektą
    let targetMember;
    try {
      targetMember = await interaction.guild.members.fetch(targetUser.id);
    } catch (err) {
      console.error("Nepavyko gauti targetMember objekto:", err);
      return interaction.reply({ content: `${errorEmoji} **Nepavyko rasti žmogaus!**`, ephemeral: true });
    }

    // Patikriname, ar žaidėjas jau turi timeout
    if (targetMember.communicationDisabledUntil) {
      return interaction.reply({ content: `${errorEmoji} **Žmogus jau yra sužalotas. Negalima padaryti tai dar kartą!**`, ephemeral: true });
    }

    try {
      // Nustatome timeout
      await targetMember.timeout(timeoutInMs, `Trenkta pagal komandos \`/trenkti\``);

      // GIF pasirinkimai
      const gifs = [
        'https://s3-us-west-1.amazonaws.com/wp.uploads.wamu.org/uploads/sites/3/2014/08/PleaseCreditJasonMorenz.gif',  // Žaibas gif
        'https://media1.giphy.com/media/xelioRxZGVPbGd0UED/giphy.gif?cid=6c09b952mbrkeypuis944r3ohzzsy2yejao2s9auzwzpvuy4&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g',  // Slap gif
        'https://media3.giphy.com/media/lkimn0qpby38zMJMY/giphy.gif?cid=6c09b952asicwmz4wgwk5pkhzyfycq9qdy62my1b6iojcxcl&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g', // Žaibas gif
        'https://gifbin.com/bin/112015/lightning-strikes-moving-car.gif',  // Trenkimo gif
        'https://media0.giphy.com/media/26uf3m46sDFVPedig/giphy.gif?cid=6c09b952t5m4no9zulgd66k2nke1hsxr8rc14h5d09xamokt&ep=v1_internal_gif_by_id&rid=giphy.gif&ct=g',  // Slap gif
        'https://i.imgur.com/DKlXxzM.gif', // Žaibas gif
        'https://i.pinimg.com/originals/4e/c4/7d/4ec47d7b87a9ce093642fc8a3c2969e7.gif', // Slap gif
        'https://www.bigfooty.com/forum/media/slap-gif.187959/full'  // Slap gif
      ];

      // Atsitiktinis GIF pasirinkimas
      const randomGif = gifs[Math.floor(Math.random() * gifs.length)];

      // Galimi užrašai su humoru
      const messages = [
        `**${targetUser.tag}** buvo nutrenktas! Už tai, kad šiek tiek peržengė ribas! 🔥`,
        `**${targetUser.tag}** pasidarė pernelyg įžūlus, ir dabar sulaukė už tai bausmės! 😈`,
        `**${targetUser.tag}** gavo didžiulį smūgį! Daugiau nepersistenk! 💥`,
        `**${targetUser.tag}** dabar tikrai pamirš, ką reiškia kalbėti nesąmones! 😜`,
        `**${targetUser.tag}** buvo pamokytas! Galvoju, kad dabar bus ramesnis... 🤔`,
        `**${targetUser.tag}** buvo trenkta per galvą, bet nesijaudink, tuomet aš neatsistovėčiau! 🤣`,
        `**${targetUser.tag}** pagaliau suprato, kad negalima taip elgtis su visais! 😏`,
        `**${targetUser.tag}** buvo nuramintas! Niekas negali praeiti be pasekmių! ⚡`
      ];

      const randomMessage = messages[Math.floor(Math.random() * messages.length)];

      const embed = new MessageEmbed()
        .setTitle("Nutrenkė žmogu!")
        .setDescription(randomMessage)  // Užrašas, priklausomai nuo atsitiktinumo
        .addField('Atsigaus po', `${randomTimeout} minutės`, true)
        .setColor("RED")
        .setImage(randomGif)  // GIF su trenktos animacijos efektu
        .setFooter({ text: "Komanda sukurė @krccdm", iconURL: interaction.user.displayAvatarURL() })
        .setTimestamp();

      await interaction.reply({ content: `${successEmoji} **Sėkmingai nutrenktas žmogus!**`, embeds: [embed] });

      // Užfiksuojame laiką, kada buvo naudota komanda
      await client.db.set(`trenkti_used_${interaction.user.id}`, Date.now());

    } catch (error) {
      console.error("Klaida vykdant trenkti komandos operaciją:", error);
      return interaction.reply({ content: `${errorEmoji} **Įvyko klaida nustatant timeout!**`, ephemeral: true });
    }
  },
};
