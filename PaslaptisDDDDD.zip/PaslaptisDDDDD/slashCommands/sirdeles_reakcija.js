// heartreaction.js

const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageActionRow, MessageButton, MessageEmbed } = require('discord.js');
const { Permissions } = require('discord.js');

// Komanda leidžia moderatoriams ir administratoriams įjungti širdelės reakcijas tam tikrame kanale
module.exports = {
  data: new SlashCommandBuilder()
    .setName('širdeles')
    .setDescription('Leidžia pridėti širdelės reakciją į žinutes tam tikrame kanale.')
    .addStringOption(option =>
      option.setName('channel')
        .setDescription('Pasirinkite kanalą, kuriame norite įjungti širdelės reakciją.')
        .setRequired(true),
    ),

  async execute(client, interaction) {
    // Patikriname, ar naudotojas turi reikalingą rolę (moderatorius arba administratorius)
    const member = interaction.member;
    const allowedRoles = ['1205932132510466140', '1200534849694466059']; // Pakeiskite su savo rolėmis ID
    const hasPermission = allowedRoles.some(roleId => member.roles.cache.has(roleId));

    if (!hasPermission) {
      return interaction.reply({ content: 'Jūs neturite teisės naudoti šios komandos.', ephemeral: true });
    }

    // Paimame kanalo ID iš pasirinkimo
    const channelId = interaction.options.getString('channel');

    // Patikriname, ar kanalą galima pasiekti
    const channel = client.channels.cache.get(channelId);

    if (!channel || channel.type !== 'GUILD_TEXT') {
      return interaction.reply({ content: 'Toks kanalas neegzistuoja arba tai nėra tekstinis kanalas.', ephemeral: true });
    }

    // Siunčiame pranešimą apie tai, kad pradėjome pridėti reakcijas
    await interaction.reply({
      content: `Pradedame pridėti širdelės reakcijas į žinutes kanale: **${channel.name}**.`
    });

    // Klausome žinučių kūrimo tam tikrame kanale
    client.on('messageCreate', async (message) => {
      // Patikriname, kad žinutė yra iš to kanalo ir kad ji nėra bot'o
      if (message.channel.id === channelId && !message.author.bot) {
        try {
          // Reaguojame su širdelės emoji
          await message.react('❤️');
        } catch (error) {
          console.error('Nepavyko pridėti reakcijos:', error);
        }
      }
    });
  },
};
