const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('skaičiuoti')
    .setDescription('Apskaičiuoti matematinį veiksmą.')
    .addStringOption(option =>
      option.setName('tipas')
        .setDescription('Pasirinkite skaičiavimo tipą:')
        .setRequired(true)
        .addChoice('sudėtis', 'sudėtis')
        .addChoice('atimtis', 'atimtis')
        .addChoice('daugyba', 'daugyba')
        .addChoice('dalijimas', 'dalijimas'))
    .addIntegerOption(option =>
      option.setName('pirmas')
        .setDescription('Pirmas skaičius')
        .setRequired(true))
    .addIntegerOption(option =>
      option.setName('antras')
        .setDescription('Antras skaičius')
        .setRequired(true)),

  async execute(client, interaction) {
    const { successEmoji, errorEmoji } = require("../emojis.json");

    const tipas = interaction.options.getString('tipas');
    const pirmas = interaction.options.getInteger('pirmas');
    const antras = interaction.options.getInteger('antras');

    const embedProcessing = new MessageEmbed()
      .setTitle('**Skaičiavimas vykdomas...**')
      .setColor("BLUE")
      .setDescription(`Apskaičiuoju \`${pirmas}\` ir \`${antras}\` naudojant veiksmą **${tipas}**...`)
      .setFooter("Skaičiuoklė")
      .setTimestamp();

    await interaction.reply({ embeds: [embedProcessing], ephemeral: true });

    let result;
    let operationSymbol;
    let operationDescription;

    switch (tipas) {
      case 'sudėtis':
        result = pirmas + antras;
        operationSymbol = '+';
        operationDescription = 'Sudėtis';
        break;
      case 'atimtis':
        result = pirmas - antras;
        operationSymbol = '-';
        operationDescription = 'Atimtis';
        break;
      case 'daugyba':
        result = pirmas * antras;
        operationSymbol = '×';
        operationDescription = 'Daugyba';
        break;
      case 'dalijimas':
        if (antras === 0) {
          const embedError = new MessageEmbed()
            .setTitle("**Klaida!**")
            .setColor("RED")
            .setDescription(`**Negalite dalinti iš nulio!**`)
            .setFooter("Skaičiuoklė")
            .setTimestamp();
          return interaction.editReply({ embeds: [embedError], ephemeral: true });
        }
        result = pirmas / antras;
        operationSymbol = '÷';
        operationDescription = 'Dalijimas';
        break;
      default:
        result = "Klaida";
        break;
    }

    const embedResult = new MessageEmbed()
      .setTitle("**Skaičiavimo Rezultatas**")
      .setColor("GREEN")
      .setDescription(`Veiksmas: \`${pirmas} ${operationSymbol} ${antras}\` (${operationDescription})`)
      .addField("Rezultatas", `\`${result}\``, true)
      .setFooter("Skaičiuoklė")
      .setTimestamp();

    await interaction.editReply({ content: `${successEmoji} **Skaičiavimas baigtas!**`, embeds: [embedResult], ephemeral: true });
  },
};
