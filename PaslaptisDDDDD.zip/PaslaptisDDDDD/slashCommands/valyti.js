const { SlashCommandBuilder } = require('@discordjs/builders');
const { MessageEmbed } = require("discord.js");
const ms = require("ms");

module.exports = {
  data: new SlashCommandBuilder()
    .setName('valyti')
    .setDescription('Ištrinkite žinutes pagal tam tikrą turinį.')
    .addStringOption(option => option.setName('raktazodis').setDescription('Raktažodis, pagal kurį bus ištrintos žinutės (pvz. "spam", "reklama").').setRequired(true))
    .addIntegerOption(option => option.setName('kiekis').setDescription('Kiek žinučių norite ištrinti (iki 100 žinučių).').setRequired(true)),

  async execute(client, interaction) {
    const { moderatorRoleId } = require("../config.json");
    const { loadingEmoji, successEmoji, errorEmoji } = require("../emojis.json");
    const modRole = interaction.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
      return console.log("[WARN] Moderatorių rolė neegzistuoja!");

    // Patikrinkite, ar vartotojas turi moderatoriaus rolę
    if (!interaction.member.roles.cache.has(modRole.id)) {
      return interaction.reply({
        content: `\`⛔\` **Trūksta leidimų:**\n\nNeturite Moderatoriaus rolės, kad galėtumėte naudoti šią komandą! \n__**Reikalinga rolė:**__ <@&${modRole.id}>`,
        ephemeral: true
      });
    }

    const keyword = interaction.options.getString('raktazodis');
    const amount = interaction.options.getInteger('kiekis');

    if (amount > 100) {
      return interaction.reply({ content: `${errorEmoji} **Negalite ištrinti daugiau nei __\`100\`__ žinučių!**`, ephemeral: true });
    }

    if (amount < 1) {
      return interaction.reply({ content: `${errorEmoji} **Įveskite teisingą žinučių kiekį (min. 1 žinutė).**`, ephemeral: true });
    }

    // Pradėti valymo procesą
    interaction.reply({ content: `${loadingEmoji} **Valoma...**`, ephemeral: true });

    // Filtruojame žinutes pagal raktazodį
    let deletedMessages = 0;
    const messages = await interaction.channel.messages.fetch({ limit: amount });

    const filteredMessages = messages.filter(msg => msg.content.includes(keyword));

    // Jei radome žinučių pagal raktazodį
    if (filteredMessages.size > 0) {
      deletedMessages = filteredMessages.size;
      await interaction.channel.bulkDelete(filteredMessages);
    }

    const embed = new MessageEmbed()
      .setDescription(`**Sėkmingai ištrintos ${deletedMessages} žinutės su raktazodžiu "${keyword}" kanale <#${interaction.channel.id}>.**`)
      .setColor("GREEN");

    await interaction.followUp({ embeds: [embed], ephemeral: true });
  },
};
