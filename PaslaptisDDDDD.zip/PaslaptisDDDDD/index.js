const { Client, Intents, Collection, MessageEmbed } = require('discord.js');
const { clientId, guildId, botActivity, clientName, mutedRoleId, prefix } = require('./config.json');
const { errorEmoji } = require("./emojis.json");
const fs = require('node:fs');
const Fs = require('node:fs');
const ms = require("ms");
const { readdirSync } = require('fs');
const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v9');
const pogger = require("pogger");
const colors = require("colors");
const Enmap = require("enmap");
const db = require("quick.db");

const client = new Client({
  intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES], disableMentions: "everyone"
});

client.db = require("quick.db");

const express = require('express');
const app = express();
const port = 3000;

app.get('/', (req, res) => res.send('<b>Hostas paruoštas.</b><br><br>Panaudokite aukščiau pateiktą nuorodą, kad laikytumėte savo botą 24/7 naudojantis uptimerobot.com.'));

app.listen(port, () =>
  pogger.success(`[SERVERIS]`.bgCyan, `Serveris paruoštas!`.green, ` Programėlė klauso adresu: https://localhost:${port}`.blue)
);

// Komandų inicializacija
client.commands = new Collection();
const commands = [];
const commandFiles = fs.readdirSync('./slashCommands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./slashCommands/${file}`);
  commands.push(command.data.toJSON());
  client.commands.set(command.data.name, command);
}

const rest = new REST({ version: '9' }).setToken(process.env.TOKEN);

(async () => {
  try {
    pogger.warning('[SLASH-HANDLER]'.bgCyan,'Pradėtas aplikacijos (/) komandų atnaujinimas...'.yellow);

    await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      { body: commands },
    );

    pogger.success('[SLASH-HANDLER]'.bgCyan,'Komandos (/) sėkmingai užregistruotos ir atnaujintos!'.green);
  } catch (error) {
    console.error(error);
  }
})();

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;

  const command = client.commands.get(interaction.commandName);

  if (!command) return;

  try {
    await command.execute(client, interaction);
  } catch (error) {
    const ConsoleIDErrorGen = Math.floor(Math.random() * 9999999) + 1;

    pogger.error(`[KLAIDA - ${ConsoleIDErrorGen}]`.bgRed, error);

    const embedErr = new MessageEmbed()
      .setTitle("Komandos vykdymas nepavyko.")
      .setDescription(`Deja, **aš negaliu įvykdyti šios komandos!** Klaida buvo užfiksuota konsolėje.`)
      .addFields({ name: "Klaidos ID:", value: `\`${ConsoleIDErrorGen}\``})
      .setColor("RED")
      .setFooter(`Prašome susisiekti su kūrėjais, kad praneštumėte apie šią problemą.`)
      .setTimestamp();

    await interaction.reply({ embeds: [embedErr], ephemeral: true });
  }
});

for(const file of readdirSync("./events")) {
    if(file.endsWith(".js")) {
        const content = require(`./events/${file}`);
        const key = file.substring(0, file.length - 3);

        client.on(key, content.bind(null, client));
    }
}

// ĮSPĖJIMAS: SNIPE KOMANDA NESUGRIAUNA DISCORD ToS. JEI KAS PASAKĖ PRIEŠINGAI, JŪS BUVO APGAULINGI.

client.snipes = new Map()

client.on('messageDelete', function(message, channel) {
  client.snipes.set(message.channel.id, {
    content: message.content,
    author: message.author.id,
    image: message.attachments.first() ? message.attachments.first().proxyURL : null
  })
})

client.on('messageCreate', async (message) => {
  if(message.content === `${prefix}snipe`){
    const { moderatorRoleId } = require("./config.json")
    const modRole = message.guild.roles.cache.find(role => role.id === moderatorRoleId);

    if (!modRole)
    return console.log("[ĮSPĖJIMAS] Modų rolė neegzistuoja!");

    if (!message.member.roles.cache.has(modRole.id)) return message.reply({ content: `\`⛔\` **Trūksta leidimų:**\nJūs neturite teisės naudoti šios komandos.`}).then(() => message.delete());
    const msg = client.snipes.get(message.channel.id)
    if(!msg) return message.reply({ content: `${errorEmoji} **Paskutinė ištrinta žinutė nerasta.**` })

    const embed = new MessageEmbed()
      .setTitle("Snipe komanda:")
      .setDescription(`**Kanalas:** <#${message.channel.id}>\n\n**Vartotojas:** <@${msg.author}>\n\n**Žinutė:** ${msg.content}`)
      .setColor("RED")
      .setFooter("ĮSPĖJIMAS: Snipe komanda nesugriauna Discord ToS.")
      .setTimestamp();

    if(msg.image) embed.setImage(msg.image)
    message.reply({ content: `<:snipemoment:949410093655556096> **Paskutinė ištrinta žinutė:**`, embeds: [embed] })
  }

  if(message.content === `${prefix}krccdm`){
    const messages = ["simps savo simpatiją", "yra labai gėjus", "labai mėgsta moteris", "yra simp, ne epik gaemer momentas", "gavo pingą cringe", "labai juokingas žmogus!!1!1!1!1!", "Įdomus faktas: ||tavo mama||"]

    const randomMessage = messages[Math.floor(Math.random() * messages.length)];

    message.reply({content: `<@635526150763970561> ${randomMessage}`})
  }
})

client.login(process.env.TOKEN);
